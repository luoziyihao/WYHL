using System;
using System.Collections.Generic;
using System.Text;


namespace ClientSendTest.Models
{
    /// <summary>
    /// �����������
    /// </summary>
    public class ReqBase:MsgBase
    {

    }
}
