using System;
using System.Collections.Generic;
using System.Text;

using ClientSendTest.Util;
using ClientSendTest.Net;

namespace ClientSendTest.Models
{
    /// <summary>
    /// ������ͷ
    /// </summary>
    public class ReqHead
    {
        /// <summary>
        /// ��ˮ��
        /// </summary>
        public string SerialNo = "";
        public string ExchCode = "";
        public string UserID = "";
        
    }
}
