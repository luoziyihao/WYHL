using System;
using System.Collections.Generic;
using System.Text;

using System.Collections;
 

namespace ClientSendTest.Net
{
    public class ArrayListMsg : ArrayList
    {

         

    }
}
