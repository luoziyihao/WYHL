using System;
using System.Collections.Generic;
using System.Text;

using System.Collections;

using ClientSendTest.Util;

namespace ClientSendTest.Net
{
    public class HashtableMsg
    {
    }
}
